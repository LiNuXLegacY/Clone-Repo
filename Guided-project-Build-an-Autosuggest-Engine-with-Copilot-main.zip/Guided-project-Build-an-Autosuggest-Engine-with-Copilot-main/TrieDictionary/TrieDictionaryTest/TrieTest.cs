namespace TrieDictionaryTest;

[TestClass]
public class TrieTest
{
    
}